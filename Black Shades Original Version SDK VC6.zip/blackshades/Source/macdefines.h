#ifndef __MACDEFINES_H
#define __MACDEFINES_H

// this is not optimum, but it works
typedef char * Str255;

#endif
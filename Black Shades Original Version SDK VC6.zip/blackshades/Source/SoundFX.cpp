#include "SoundFX.h"

SoundFX *SoundFX::m_singleton = NULL;
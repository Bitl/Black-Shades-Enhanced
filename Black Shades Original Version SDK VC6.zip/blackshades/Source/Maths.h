#ifndef _MATHS_H_
#define _MATHS_H_


/**> HEADER FILES <**/
#include <cmath>

double fast_sqrt (register double arg);

#endif

